//#define DEBUG

#include <stdio.h>
#include <iostream>

#include "library.hpp"

double Mult100( double val_in)
{
    double val_inMult;
    val_inMult = val_in * 100;

    return val_inMult;
}

#ifdef DEBUG

 int main(int argc, char const *argv[]) {

   double out_x, out_y, in_x, in_y;
   in_x = 22;
   in_y = 33;
   out_x = Mult100(in_x);
   out_y = Mult100(in_y);

   std::cout << "X:" << out_x << '\n';
   std::cout << "Y:" << out_y << '\n';

   return 0;
 }

#endif
