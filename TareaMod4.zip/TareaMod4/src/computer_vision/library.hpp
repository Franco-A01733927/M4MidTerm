#define EXPORT extern "C"

#ifndef LIB1_H_INCLUDED
#define LIB1_H_INCLUDED

EXPORT double Mult100(double val_in);

#endif /* LIB1_H_INCLUDED */
