#!/usr/bin/python3
#Franco Minutti Simoni
#25/05/2023
#Detecta puntos verdes y entrega las coordenadas en el topico


from cv_bridge import CvBridge
import cv2
import ctypes
import rospy
from sensor_msgs.msg import Image


def image_callback(msg):

    bridge = CvBridge()
    cv_image = bridge.imgmsg_to_cv2(msg, "bgr8")

    pub = rospy.Publisher('/g_coord', Point, queue_size=1)
    point = Point()
    point.x = x
    point.y = y
    pub.publish(point)

def cam_node():
    rospy.init_node('cam_node', anonymous=True)

    bridge = CvBridge()
    image_pub = rospy.Publisher('/cam/image_raw', Image, queue_size=10)

    cam = cv2.VideoCapture(0)

    rate = rospy.Rate(10)

    while not rospy.is_shutdown():

        ret, frame = cam.read()

        if ret:

            img_msg = bridge.cv2_to_imgmsg(frame, "bgr8")

            image_pub.publish(img_msg)

        rate.sleep()

    cam.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        cam_node()
    except rospy.ROSInterruptException:
        pass
